﻿Login Details for user:

Username : user@gmail.com
Password: Test@123

Username: admin
Password: Pass2022